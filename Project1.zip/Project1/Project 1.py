#!/usr/bin/env python
# coding: utf-8

# ### Sara Amato: Project 1

# Design and implement your own algorithm that takes the array A with size m+n as input where:
# 
# Subarray A[1], A[2],...A[m] sorted in ascending order
# Subarray A[m+1], A[m+2],...A[n] sorted in ascending order
# and merges the two subarrays using an auxiliary array Aux of size min {m, n} back into array A sorted in ascending order. You must design and implement your own sorting function. Use of sorting functions in libraries is not permitted.

# In[379]:


import numpy as np


# In[402]:


def prob1(x, y):
    x_size = len(x)
    y_size = len(y)
    m = x_size
    l = y_size
    n = m + l
    aux = [0]* n
    np.array(aux)
    A = x+y
    np.array(A)
    mid = A[m]
    i = 0
    j = 0
    k = 0
    A = []
    while i< m and j< l:
        if x[i] < y[j]:
            aux[k] = x[i]
            k = k +1
            i = i +1
        else:
            aux[k] = y[j]
            k = k +1
            j = j +1
    while i < m:
        aux[k] = x[i]
        k = k +1
        i = i +1
    while j < l:
        aux[k] = y[j]
        k = k +1
        j = j +1
    
    for i in range (n):
        A.append (aux[i])
        #A =  aux[i]
    print (A)


# In[403]:


#Test Case 1: 
prob1([] ,[3, 7, 9])


# In[404]:


#Test Case 2
prob1([2,7,8], [1])


# In[405]:


#Test Case 3
prob1([1, 7, 10, 15], [3, 8, 12, 18])


# In[406]:


#Test Case 4
prob1([1, 3, 5, 5, 15, 18, 21], [5, 5, 6, 8, 10, 12, 16, 17, 17, 20, 25, 28])


# ## Ala Carte

# In[382]:


def ala_carte(x, y):
    if x< 0 and y > 0:
        result = 'negative'
    elif x > 0 and y < 0:
        result = 'negative'
    else: 
        result = 'positive'
    multiplier = abs(x)
    multiplicant = abs(y)
    list1 = [multiplier]
    list2 = [multiplicant]
    while multiplier >= 1:
        multiplier = multiplier/2
        list1.append(multiplier)

    for x in range (len(list1)):
        multiplicant = multiplicant*2
        list2.append(multiplicant)
    dict_a = dict(zip(list1, list2))
    #print(dict_a)
    list3 = []
    for key in dict_a:
        if(int(key)%2 != 0):
            list3.append(dict_a[key])
    total = sum(list3)
    
    if result == 'negative':
            print(-total)
    else:
        print(total)
  
             
            
    
  
    
    


# In[383]:


#Test Case 1 
ala_carte(7000, 7294)


# In[384]:


#Test Case 2 
ala_carte(25, 5038385)


# In[385]:


#Test Case 3 
ala_carte(-59724, 783)


# In[386]:


#Test Case 4 
ala_carte(8516, -82147953548159344)


# In[387]:


#Test Case 5 
ala_carte(45952456856498465985, 98654651986546519856)


# In[388]:


#Test Case 6 
ala_carte(-45952456856498465985, -98654651986546519856)


# ##  Rectangle Multiplication

# In[389]:


import numpy as np
import math


# In[390]:


def rectangle (x,y):
    if x< 0 and y > 0:
        sign = 'negative'
    elif x > 0 and y < 0:
        sign = 'negative'
    else: 
        sign = 'positive'
    x = abs(x)
    y = abs(y)
    digits_x = [int(n) for n in str(x)]
    digits_y = [int(n) for n in str(y)]
    list1 = []
    list2 = []
    mat_even = []
    mat_odd = []
    result =[]
    size_x = len(digits_x)
    size_y = len(digits_y) 
    size = (size_y + size_x) + 1
    for k in digits_y:
        for j in digits_x:
            mult = j*k
            list1.append(str(mult).zfill(2))
    for l in list1:
        digits_mult = [int(n) for n in str(l)]
        list2.append(digits_mult[0])
        list2.append(digits_mult[1])
    mat = np.array(list2)
    for i in range (0, len(mat), 2):
        mat_even.append(mat[i])
        mat_even.append(0)
    for i in range (1, len(mat), 2):
        mat_odd.append(0)
        mat_odd.append(mat[i])
    n_odd = len(mat_odd) - 2
    n_even = len(mat_even) - 2
    while len(mat_odd) > 0 or len(mat_even) > 0:
        for j in range(size_x*2):
                result.append(mat_odd.pop())
        for i in range(size_x*2):
            result.append(mat_even.pop())
    #result = list(reversed(result))
    
    matrix = np.array(result).reshape( size_y*2, size_x *2)
    #print(matrix)
    rows = len(matrix)
    cols = len(matrix[0])
    diags = [[matrix[sum_-k][k]
          for k in range(sum_ + 1)
          if (sum_ - k) < rows and k < cols]
         for sum_ in range(rows + cols - 1)]
    n_diags = (len(diags))
    carryover = 0
    total = []
    answer = []
    for l in range(0, n_diags, 2):
        sum_a = sum(diags[l])
        if ((sum_a + carryover) >= 10):
            total.append((sum_a + carryover) % 10 )
            carryover = math.floor((sum_a + carryover) /10)
        else:
            total.append((sum_a + carryover) %10)
            carryover = 0
    for i in range(len(total) -1 , -1, -1):
        answer.append(total[i])
    if sign == 'negative':
        answer.insert(0, '-')
    for i in answer: 
        print(i, end="" ) 
       
            
    


# In[391]:


rectangle(981,1234)


# In[392]:


#Test Case 1 
rectangle(7000, 7294)


# In[393]:


#Test Case 2 
rectangle(25, 5038385)


# In[394]:


#Test Case 3 
rectangle(-59724, 783)


# In[395]:


#Test Case 4
rectangle(8516, -82147953548159344)


# In[396]:


#Test Case 5 
rectangle(45952456856498465985, 98654651986546519856)


# In[397]:


#Test Case 6 
rectangle(-45952456856498465985, -98654651986546519856)


# In[ ]:




